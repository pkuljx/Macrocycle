#!/usr/bin/env python
# coding: utf-8

# In[1]:


#!/usr/bin/env python
# coding: utf-8

# In[164]:


#!/usr/bin/env python
# coding: utf-8

# In[450]:


from rdkit import Chem
import glob
import numpy as np
from Bio.PDB import *
from Bio.PDB.ResidueDepth import get_surface
import numpy as np
from Bio.PDB.PDBIO import Select
from Bio.PDB.ResidueDepth import min_dist
import joblib
from Bio.PDB.Atom import Atom
#from scipy.spatial import distance
from scipy.spatial.transform import Rotation
import os,sys
import math
import pandas as pd
import math
 
# Function to find Angle of two planes
def angle_two_planes(a1, b1, c1, a2, b2, c2):
    #general equation of a plane Ax + By + Cz + D = 0 
    d = ( a1 * a2 + b1 * b2 + c1 * c2 )
    e1 = math.sqrt( a1 * a1 + b1 * b1 + c1 * c1)
    e2 = math.sqrt( a2 * a2 + b2 * b2 + c2 * c2)
    d = d / (e1 * e2)
    


    #print(d)
    if d>1:d=1
    if d<-1:d=-1    
    A = math.degrees(math.acos(d))
    if math.isnan(A): A=0
    if(A>90): A=180-A
    #print("Angle is", A, "degree",a1, b1, c1, a2, b2, c2,math.isnan(A))
    
    
    return A

def equation_plane(p, q, r):
    #general equation of a plane Ax + By + Cz + D = 0
    x1 = p[0]
    y1 = p[1]
    z1 = p[2]
    x2 = q[0]
    y2 = q[1]
    z2 = q[2]
    x3 = r[0]
    y3 = r[1]
    z3 = r[2]
     
    # For Finding value of A, B, C, D
    a1 = x2 - x1
    b1 = y2 - y1
    c1 = z2 - z1
    a2 = x3 - x1
    b2 = y3 - y1
    c2 = z3 - z1
    A = b1 * c2 - b2 * c1
    B = a2 * c1 - a1 * c2
    C = a1 * b2 - b1 * a2
    D = (- A * x1 - B * y1 - C * z1)
    return A,B,C,D

def angle_between_plan_points(points_set1, points_set2):
  A1,B1,C1,D1=equation_plane(points_set1[0],points_set1[1],points_set1[2])
  A2,B2,C2,D2=equation_plane(points_set2[0],points_set2[1],points_set2[2])
  #print("input coordinates:")
  #print(points_set1[0],points_set1[1],points_set1[2])
  #print(points_set2[0],points_set2[1],points_set2[2])
  A=angle_two_planes(A1, B1, C1, A2, B2, C2)
  return A

def rotation_matrix(A,B):
# a and b are in the form of numpy array

   ax = A[0]
   ay = A[1]
   az = A[2]

   bx = B[0]
   by = B[1]
   bz = B[2]

   au = A/(np.sqrt(ax*ax + ay*ay + az*az))
   bu = B/(np.sqrt(bx*bx + by*by + bz*bz))

   R=np.array([[bu[0]*au[0], bu[0]*au[1], bu[0]*au[2]], [bu[1]*au[0], bu[1]*au[1], bu[1]*au[2]], [bu[2]*au[0], bu[2]*au[1], bu[2]*au[2]] ])


   return(R)



def rotation_matrix_from_vectors(vec1, vec2):
    """ Find the rotation matrix that aligns vec1 to vec2
    :param vec1: A 3d "source" vector
    :param vec2: A 3d "destination" vector
    :return mat: A transform matrix (3x3) which when applied to vec1, aligns it with vec2.
    """
    a, b = (vec1 / np.linalg.norm(vec1)).reshape(3), (vec2 / np.linalg.norm(vec2)).reshape(3)
    v = np.cross(a, b)
    c = np.dot(a, b)
    s = np.linalg.norm(v)
    kmat = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    rotation_matrix = np.eye(3) + kmat + kmat.dot(kmat) * ((1 - c) / (s ** 2))
    return rotation_matrix

def np_angle(a,b):


    inner = np.inner(a, b)
    norms = np.linalg.norm(a) * np.linalg.norm(b)

    cos = inner / norms
    rad = np.arccos(np.clip(cos, -1.0, 1.0))
    deg = np.rad2deg(rad)
    return deg



def wiki_dihedral(p):
    """formula from Wikipedia article on "Dihedral angle"; formula was removed
    from the most recent version of article (no idea why, the article is a
    mess at the moment) but the formula can be found in at this permalink to
    an old version of the article:
    https://en.wikipedia.org/w/index.php?title=Dihedral_angle&oldid=689165217#Angle_between_three_vectors
    uses 1 sqrt, 3 cross products"""
    p0 = p[0]
    p1 = p[1]
    p2 = p[2]
    p3 = p[3]

    b0 = -1.0*(p1 - p0)
    b1 = p2 - p1
    b2 = p3 - p2

    b0xb1 = np.cross(b0, b1)
    b1xb2 = np.cross(b2, b1)

    b0xb1_x_b1xb2 = np.cross(b0xb1, b1xb2)

    y = np.dot(b0xb1_x_b1xb2, b1)*(1.0/np.linalg.norm(b1))
    x = np.dot(b0xb1, b1xb2)

    return np.degrees(np.arctan2(y, x))

class Cycle_link():
    def __init__(self,vectors_idx=None, vectors_xyz=None,vectors_link=None,link_type=None):
        self.vectors_idx=vectors_idx ##atom points/vectors to connect
        self.vectors_xyz=vectors_xyz
        self.vectors_link=vectors_link
        self.link_size = len(vectors_link)
        self.link_type=link_type
    def get_distance(self):
        pos_v1 = self.vectors_xyz[0][0]
        pos_v2 = self.vectors_xyz[1][0]
        #print(pos_v1,pos_v2)
        #return distance.euclidean(pos_v1, pos_v2)
        distance = np.linalg.norm(pos_v1-pos_v2)
        self.distance = distance
        return(distance)
    def get_angle(self):
        angle=np_angle(self.vectors_xyz[0][1]-self.vectors_xyz[0][0],self.vectors_xyz[1][1]-self.vectors_xyz[1][0])
        self.angle = angle
        return(angle)
    def get_dihedral(self):
        dihedral =wiki_dihedral(self.vectors_xyz[0]+self.vectors_xyz[1])
        self.dihedral=dihedral
        return(dihedral)
    def set_link_distance(self,d):
        self.link_distance = d
        
def xyz_vector(cycle_xyz_dict,vector_idx):   
    #coordinates for the 4 atoms
    pos_1= cycle_xyz_dict[vector_idx[0]]
    pos_2= cycle_xyz_dict[vector_idx[1]]
    return([pos_1,pos_2])

def atom_distance(cycle_xyz_dict,atom_idx):   
    pos_1= cycle_xyz_dict[atom_idx[0]]
    pos_2= cycle_xyz_dict[atom_idx[1]]
    return(np.linalg.norm(pos_1-pos_2))

class Ligand_cycle():
 def __init__(self,ligand_mol=None, ligand_cycle=None,ligand_ref=None):
    self.ligand_mol=ligand_mol
    self.ligand_cycle=ligand_cycle
    self.ligand_ref=ligand_ref
    #
    conf = ligand_mol.GetConformer()
    cycle_xyz_dict = {}
    for aidx in ligand_cycle:
        pos =conf.GetAtomPosition(aidx)
        cycle_xyz_dict[aidx]=np.array([pos.x,pos.y,pos.z])
    # vector pair
    #print(ligand_ref,ligand_cycle)
    connector_vectors=[]
    for idx,item in enumerate(ligand_cycle):
        #print("cycle loop",ligand_cycle[:idx],item,ligand_cycle[idx+1:],[item]+ligand_cycle[idx+1:]+ligand_cycle[:idx]+[item])
        cycle_loop = [item]+ligand_cycle[idx+1:]+ligand_cycle[:idx]+[item]
        vector1 = (cycle_loop[0],cycle_loop[1])
        vector1_xyz =  xyz_vector(cycle_xyz_dict,vector1)
        vector1_reverse = (cycle_loop[1],cycle_loop[0])
        vector1_reverse_xyz =  xyz_vector(cycle_xyz_dict,vector1_reverse)
        for idy in range(len(cycle_loop)-1,1,-1):
            vector2_forward = [cycle_loop[idy],cycle_loop[idy-1]]
            vector2_forward_link = cycle_loop[2:idy-1]
            vector2_reverse = [cycle_loop[idy-1],cycle_loop[idy]]
            vector2_reverse_link = cycle_loop[idy+1:len(cycle_loop)-1]
            #print("forward",vector2_forward,vector2_forward_link)
            #print("reverse",vector2_reverse,vector2_reverse_link)
            
            obj_forward = Cycle_link(vectors_idx=[vector1,vector2_forward], vectors_xyz=[xyz_vector(cycle_xyz_dict,vector1),
                                        xyz_vector(cycle_xyz_dict,vector2_forward)],vectors_link=vector2_forward_link,link_type='forward')
            obj_reverse = Cycle_link(vectors_idx=[vector1_reverse,vector2_reverse], vectors_xyz=[xyz_vector(cycle_xyz_dict,vector1_reverse),
                                        xyz_vector(cycle_xyz_dict,vector2_reverse)],vectors_link=vector2_reverse_link,link_type='reverse')
            if obj_forward.link_size:
                
                ("forward",obj_forward.get_distance(), obj_forward.get_angle(),obj_forward.get_dihedral())
                #print(obj_forward.vectors_idx, obj_forward.vectors_link)
                link_distance =atom_distance(cycle_xyz_dict,(obj_forward.vectors_link[0],obj_forward.vectors_link[-1]))
                obj_forward.set_link_distance(link_distance)    
                #print("forward link d",link_distance)
                connector_vectors.append(obj_forward)
            if obj_reverse.link_size:
                ("reverse",obj_reverse.get_distance(), obj_reverse.get_angle(),obj_reverse.get_dihedral())
                #print(obj_reverse.vectors_idx, obj_reverse.vectors_link)
                link_distance =atom_distance(cycle_xyz_dict,(obj_reverse.vectors_link[0],obj_reverse.vectors_link[-1]))
                obj_reverse.set_link_distance(link_distance)  
                #print("reverse link d", link_distance)
                connector_vectors.append(obj_reverse)
      
    self.connector_vectors=connector_vectors     
    #print(len(self.connector_vectors)," options in one cycle in ", ligand_ref )
            #print("forward",vector1,[cycle_loop[idy],cycle_loop[idy-1]],cycle_loop[2:idy-1])
            #if(idy+1<len(cycle_loop)-1): print("reverse",vector1_reverse,[cycle_loop[idy-1],
            #                                                              cycle_loop[idy]],cycle_loop[idy+1:len(cycle_loop)-1])
    
        
    if(0):  
      print(cycle_loop)
      for idx_x in range(len(cycle_loop)):
        vector1 = [cycle_loop[idx_x],cycle_loop[idx_x+1]]
        print(vector1)
        
        for idx_y in range(idx_x+4,len(cycle_loop)-1):
            vector2 = [cycle_loop[idx_y],cycle_loop[idx_y+1]]
            print(vector1, vector2)
        for idx_y in range(idx_x-3):
            vector2 = [cycle_loop[idx_y],cycle_loop[idx_y-1]]
            print(vector1, vector2)            
        



 
 


# In[172]:


class Atomselect:
   def __init__(self,atom_ids=None):
      self.atom_ids = atom_ids

   def __repr__(self):
        """Represent the output as a string for debugging."""
        return "<Select all>"

   def accept_residue(self, residue):
      return 1

   def accept_chain(self, chain):
      return 1


   def accept_model(self, model):
       if(model.get_id()==0): return True
       else: return False


   def accept_atom(self, atom):
      if(atom.get_serial_number() in self.atom_ids):return True
      else:False

def write_target_link(link_type,ligand_ref, link_atomIdx, trans_vector,vector_atomIdx,first_atom,r_matrix=None):        
  #print(ligand_ref)
  parser = PDBParser(PERMISSIVE = True, QUIET = True)
  
  io = PDBIO()
  
  cols = ligand_ref.split("/")[1][:-4].split('_')
  ligand = cols[0]
  pdb = cols[1]
  chain_id = cols[2]
  structure = parser.get_structure(pdb,ligand_ref[:-4]+'.pdb')
  if(1):
   for model in structure.get_models():
    for chain in model.get_chains():
      for residue in chain.get_residues():
        for atom in residue.get_atoms():
            #print([atom.get_id(),atom.get_serial_number(),atom.get_full_id()])
        
            if r_matrix is not None:
                #print(atom.get_coord(),r_matrix.apply(atom.get_coord()),trans_vector)
                #rotate then translate
                atom.set_coord(r_matrix.apply(atom.get_coord())+trans_vector)
                #print('atom',atom.get_coord())
            else:
                internal_r = first_atom-atom.get_coord()
                
                
                #print(internal_r)
                
                atom.set_coord(first_atom+trans_vector-internal_r)    
               
          
          
  io.set_structure(structure)
  name = 'size{}-'.format(len(link_atomIdx)-4)+'to'.join([str(item+1) for item in vector_atomIdx[0]])+'_'+'to'.join([str(item+1) for item in vector_atomIdx[1]])
  name = name + '-'+ link_type
  name = name + '-'+'-'.join([str(item) for item in link_atomIdx])
  aligned_ref = "./{}/{}_{}_{}_ligand_{}_aligned_ref.pdb".format(output_dir,ligand,pdb,chain_id,name)
  io.save(aligned_ref)
  io.save("./{}/{}_{}_{}_ligand_{}_linker.pdb".format(output_dir,ligand,pdb,chain_id,name), 
          Atomselect(atom_ids=[item+1 for item in link_atomIdx]))
  #keep the two starting atoms
  #input_structure_atoms
  #print("{}_{}_{}_ligand_{}.pdb".format(ligand,pdb,chain_id,name))
  input_atoms=[]  
  for model in structure.get_models():
    for chain in model.get_chains():
      for residue in chain.get_residues(): 
        ref_atoms_size = len(list(residue.get_atoms()))
        #print(ref_atoms_size)
        serial_number=ref_atoms_size
        existing_atoms=[]
        for atom in  residue.get_atoms():
             existing_atoms.append(atom.get_name())
        #    print(atom.get_name(),atom.get_fullname(), atom.get_serial_number(),[atom.element],atom.id)        
        for atom in input_structure_atoms:
            serial_number=serial_number+1
            _name = atom.element+str(serial_number)
            if _name in existing_atoms:_name=_name+'B'
            new_atom =Atom(name=_name, coord=atom.get_coord(), bfactor=atom.get_bfactor(), 
                           occupancy=atom.get_occupancy(),altloc=atom.get_altloc(),fullname=_name,
                          serial_number=serial_number, element=atom.element)
            input_atoms.append(serial_number)
            
            residue.add(new_atom)

        
  starting_atoms = [vector_atomIdx[0][0],vector_atomIdx[1][0]]
  #print(starting_atoms, vector_atomIdx)
  #print(link_atomIdx)
  io.save("./{}/{}_{}_{}_ligand_{}_connected.pdb".format(output_dir,ligand,pdb,chain_id,name), 
          Atomselect(atom_ids=[item+1 for item in link_atomIdx if item not in starting_atoms]+input_atoms))
  return "{}_{}_{}_ligand_{}_linker.pdb".format(ligand,pdb,chain_id,name), "{}_{}_{}_ligand_{}_aligned_ref.pdb".format(ligand,pdb,chain_id,name)
            


        

    


# In[445]:

def prepare_ligand_cycle_list():
  parser = PDBParser(PERMISSIVE = True, QUIET = True)
  
  io = PDBIO()
  
          
          
  #to save
  ligand_cycle_list = []
  #ligand_cycle_list=joblib.load("ligand_cycle_list.joblib")
  #print("done loading")
  count =0
  #for sdf in glob.glob("ligand_only/*.sdf"):
    #mols = Chem.SDMolSupplier(sdf,removeHs=False,strictParsing=False,sanitize=True)
  if(len(ligand_cycle_list)==0):    
   print(len(glob.glob("ligand_only/*.sdf")))
   for sdf in   glob.glob("ligand_only/*.sdf"): 
    mols = Chem.SDMolSupplier(sdf,removeHs=True,strictParsing=True,sanitize=True)
   #for sdf in   glob.glob("ligand_only/*.pdb"):  
    #mols = [Chem.MolFromPDBFile(sdf,removeHs=True,sanitize=True)]    
    #mols = [Chem.MolFromPDBFile(sdf)]
    for mol in mols:
      #for atom in mol.GetAtoms():
      #  print(atom.GetAtomicNum(), atom.GetIdx())
       
      if(mol is None):
         
         print("debug: ",sdf)
         continue   
            ##to debug those sdf files
         ##to debug 0N1_4dpi sdf file 
      if(1):
        
        rings=mol.GetRingInfo()
        try:
          conf = mol.GetConformer()
        except:
          print("debug: ",sdf)
          continue
        conf = mol.GetConformer()  
        atomrings = rings.AtomRings()
        #print(sdf, atomrings)
        for ring  in atomrings:
          if(len(ring)>=8):
            #print([ item+1 for item in ring],sdf)
            for aidx in ring:
                  pos =conf.GetAtomPosition(aidx)
                  #print(aidx,pos.x, pos.y,pos.z)
            one_ligand_cycle=Ligand_cycle(ligand_mol=mol,ligand_cycle=list(ring),ligand_ref=sdf)    
            ligand_cycle_list.append(one_ligand_cycle)
  
    count = count +1
    total_count =6000
    if is_test: total_count =100
         
    if(count>total_count):break
        #for atom in mol.GetAtoms():
        #	print(dir(atom))
        #	print(atom.GetAtomicNum(), atom.GetIdx())
        #stop	
   #joblib.dump(ligand_cycle_list,"ligand_cycle_list.joblib")
  return ligand_cycle_list

# In[451]:



# In[173]:


def get_sorting_distance(a_2points,b_2points):
    distance_1=min([np.linalg.norm(a_2points[0]-item) for item in b_2points])
    distance_2=min([np.linalg.norm(a_2points[1]-item) for item in b_2points])
    return 1/2*(distance_1+distance_2)
    

def search(input_v_1, input_v_2):
  print("start searching")
  #(ligand_cycle.ligand_ref,saved_file, [item+1 for item in cycle_link.vectors_link],
  #                cycle_link.link_distance,cycle_link.link_size, cycle_link.distance, cycle_link.angle, cycle_link.dihedral)  
  result_lines=['reference ligand,saved link,linking atoms,link distance,link size,connection point:disance,connection point:angle,connection point:dihedral,rmsd,sort distance,sort angle\n']
   

  input_distance=np.linalg.norm(np.array(input_v_1)[0]-np.array(input_v_2)[0])
  input_angle= np_angle(input_v_1[1]-input_v_1[0],input_v_2[1]-input_v_2[0])
  input_dihedral=wiki_dihedral(input_v_1+input_v_2)    
  print(input_distance,input_angle,input_dihedral)
  result_lines.append(','.join([
                  'query','query', 
                'query',
                  '','', 
                        str(input_distance) , str(input_angle), str(input_dihedral),'',''])+'\n')  
  
  for ligand_cycle in ligand_cycle_list:
    #for connector_vector in ligand_cycle.connector_vectors:
    #
        
        conf = ligand_cycle.ligand_mol.GetConformer()
        

        rings=ligand_cycle.ligand_mol.GetRingInfo()


        atomrings = rings.AtomRings()
     
        
        cycle_xyz_dict = {}
        #if "0BI_3k5c_C" not in ligand_cycle.ligand_ref:continue
        #print(ligand_cycle.ligand_ref)
        pos_error=False
        for ring in atomrings:
         if(len(ring)<8):continue   
         for aidx in ring:
          pos=conf.GetAtomPosition(aidx)  
          #try:pos =conf.GetAtomPosition(aidx)
          #except:  pos_error=True
          #if pos_error: continue 
          cycle_xyz_dict[aidx]=np.array([pos.x,pos.y,pos.z])
        if(pos_error):continue
        atoms = ligand_cycle.ligand_mol.GetAtoms()
        for cycle_link in ligand_cycle.connector_vectors:
            v_input = [input_v_1[1]-input_v_1[0],input_v_2[1]-input_v_2[0]]
            
            v_ref = [cycle_link.vectors_xyz[0][1] - cycle_link.vectors_xyz[0][0],
                     cycle_link.vectors_xyz[1][1] - cycle_link.vectors_xyz[1][0]]
            #np.array(cycle_link.vectors_xyz[0]+cycle_link.vectors_xyz[1])
                
            r_matrix, rmsd =  Rotation.align_vectors(v_input,v_ref) #(a,b) b-->a
            #print("HERE",r_matrix,rmsd)
            #if(rmsd<0.5):
            #if(abs(cycle_link.distance-input_distance)<0.2*input_distance and abs(cycle_link.angle-input_angle)<0.2*input_angle
            #  and abs(cycle_link.dihedral-input_dihedral)<abs(0.2*input_dihedral) and rmsd<1):
            
            if(abs(cycle_link.distance-input_distance)<1 and 
               abs(cycle_link.angle-input_angle)<20 and
              #(abs(cycle_link.dihedral-input_dihedral)<abs(0.2*input_dihedral) or abs(cycle_link.dihedral+input_dihedral)<abs(0.2*input_dihedral)) and 
             rmsd<1):
             
              transform_vector=[0,0,0]
              v_ref_xyz_rot = r_matrix.apply(cycle_link.vectors_xyz[0]+cycle_link.vectors_xyz[1])  
              v_input_xyz = input_v_1+input_v_2
                
              #  center of 4 points
              if(0):  
                v_ref_xyz_rot_center =1/4*v_ref_xyz_rot[0]
                for i in range(1,4):
                    print(i)
                    v_ref_xyz_rot_center=v_ref_xyz_rot_center+v_ref_xyz_rot[i]*1/4
           
                v_input_xyz_center =1/4*v_input_xyz[0]
                for i in range(1,4):
                    v_input_xyz_center=v_input_xyz_center+v_input_xyz[i]*1/4                    
                print(v_ref_xyz_rot,v_input_xyz)  
                print(v_ref_xyz_rot_center,v_input_xyz_center)
              
                transform_vector=  v_input_xyz_center-v_ref_xyz_rot_center
              #  
              # center of 2 starting points
              transform_vector=1/2*(v_input_xyz[0]+v_input_xyz[2]) - 1/2*(v_ref_xyz_rot[0]+v_ref_xyz_rot[2])  
            
              #print('ref xyz',cycle_link.vectors_xyz[0]+cycle_link.vectors_xyz[1])
                
                
              #for item in v_ref_xyz_rot:
              #      print("A",item+transform_vector)
              #print("B r_matrix.apply(item)+transform_vector,item ,transform_vector,r_matrix.apply(item)")
              #for item in  cycle_link.vectors_xyz[0]+cycle_link.vectors_xyz[1]:
                #print("B",rmsd,r_matrix.apply(item)+transform_vector,item ,transform_vector,r_matrix.apply(item))
               
              sort_distance=get_sorting_distance([v_ref_xyz_rot[0]+transform_vector,v_ref_xyz_rot[2]+transform_vector]
                                                 ,[v_input_xyz[0],v_input_xyz[2]]) 
                
              if(sort_distance>=sort_distance_threshold):continue  
                
              plane_points_set1 =[1/2*(v_input_xyz[1]+v_input_xyz[3]),v_input_xyz[0],v_input_xyz[2]]  
              plane_points_set2 = [ 1/2*(v_ref_xyz_rot[1]+v_ref_xyz_rot[3])+transform_vector,
                                   v_ref_xyz_rot[0]+transform_vector,v_ref_xyz_rot[2]+transform_vector]
              sort_angle=angle_between_plan_points(plane_points_set1,plane_points_set2)  
              #print("sorting ",sort_distance,sort_angle)
              
              #stop      
              #continue     
              #transform vector
              first_atom=cycle_link.vectors_xyz[0][1]
              if(0):
                a = np.array(input_v_1+input_v_2)
                b = np.array(cycle_link.vectors_xyz[0]+cycle_link.vectors_xyz[1])
                m=rotation_matrix(a,b)
                print(a, b, m@a)
               
              if(0):
                a = np.array(input_v_1+input_v_2)
                b = np.array(cycle_link.vectors_xyz[0]+cycle_link.vectors_xyz[1])
                
                r_matrix, rmsd =  Rotation.align_vectors(a,b) 
                #r_matrix=r_matrix.as_matrix()

                print(r_matrix,rmsd)
              if(0):
                first_atom=cycle_link.vectors_xyz[0][1]
                input_atom_first = input_v_1[1]
                transform_vector = input_atom_first-first_atom
            
                second_atom=cycle_link.vectors_xyz[1][1]
                second_atom_trans=first_atom+transform_vector-(first_atom-second_atom)
                input_atom_second = input_v_2[1]
                print(second_atom_trans,input_atom_second,"here",np.linalg.norm(second_atom_trans-input_atom_second))
            
                v_ref = first_atom+transform_vector - (first_atom+transform_vector-(first_atom-cycle_link.vectors_xyz[0][0]))
                v_input =   input_v_1[1]-input_v_1[0]
            
              ref_dihedral = cycle_link.dihedral
              if 0 and (np.linalg.norm(second_atom_trans-input_atom_second)>2):### parameter
                    #switch input order
                    transform_vector = input_atom_second-first_atom
                    #first_atom_trans = second_atom+transform_vector-(second_atom-first_atom)
                    second_atom_trans=first_atom+transform_vector-(first_atom-second_atom)
                    if(np.linalg.norm(second_atom_trans-input_atom_first)>2):continue ##parameter
                    v_ref = first_atom+transform_vector - (first_atom+transform_vector-(first_atom-cycle_link.vectors_xyz[0][0]))
                    v_input =   input_v_2[1]-input_v_2[0]
                    print(ref_dihedral,'before',np_angle(v_ref,v_input))
                    
                    print(np.linalg.norm(second_atom_trans-input_atom_first), 'distance',np_angle(v_ref,v_input),'angle')
                    ref_dihedral=wiki_dihedral(cycle_link.vectors_xyz[1]+cycle_link.vectors_xyz[0])
                    print(ref_dihedral,'after',np_angle(v_ref,v_input))
                    if abs(ref_dihedral-input_dihedral)>abs(0.15*input_dihedral):continue
                    
                    
              #transform_vector2 = input_atom_second-second_atom            
              
              #print(transform_vector,transform_vector2)
              #stop
              ##CHEck angle

              if 0 and (np_angle(v_ref,v_input)>10):continue###parameter
              #r_matrix=None
              #
              #print(np_angle(v_ref,v_input),'angle') 
              #print(v_ref,v_input)      
                
              atom_idx_list= list(cycle_link.vectors_idx[0]) +cycle_link.vectors_link+list(cycle_link.vectors_idx[1]) 
              saved_file,aligned_ref=write_target_link(cycle_link.link_type,ligand_cycle.ligand_ref, atom_idx_list,
                                           transform_vector,cycle_link.vectors_idx,first_atom,r_matrix)
              print(aligned_ref,saved_file, '-'.join([str(item+1) for item in cycle_link.vectors_link]),
                  cycle_link.link_distance,cycle_link.link_size, cycle_link.distance,
                    cycle_link.angle, ref_dihedral,rmsd,sort_distance)  
              result_lines.append(','.join([
                  aligned_ref,saved_file, 
                '-'.join([str(item+1) for item in cycle_link.vectors_link]),
                  str(cycle_link.link_distance),str(cycle_link.link_size), str(cycle_link.distance),
                                            str(cycle_link.angle), str(ref_dihedral),str(rmsd),
                  str(sort_distance),str(sort_angle)])+'\n')
              #stop  
              continue
  with open('./{}/link_information.csv'.format(output_dir),'w+') as fw:       
    fw.writelines(result_lines)
  print("done search")  
  if(0):              
              rdmol = Chem.RWMol(ligand_cycle.ligand_mol)
              for idx,xyz in cycle_xyz_dict.items():
                conf.SetAtomPosition(idx, xyz+transform_vector)
                
                
              new_idx_list = []
              for idx_ in cycle_link.vectors_link:
                new_idx_=rdmol.AddAtom(atoms[idx_])
                print(new_idx_)
                
              conf_ = rdmol.GetConformer()
              for idx_ in new_idx_list:
                    pos =conf_.GetAtomPosition(idx_)
                    print(pos.x)

                    


# In[2]:



#is_test = True

#ligand_cycle_list = prepare_ligand_cycle_list()

#print(len(ligand_cycle_list)) 


# In[4]:





#input_v_1 = [np.array((129.466, 118.451, 136.12 )),np.array(( 129.177, 117.901, 137.010 ))]     
#input_v_2 = [np.array(( 127.943, 114.228, 132.256 ) ),np.array(( 127.083, 114.115, 132.916))] 
#input_pdb_file = 'KIF18A_macro.pdb'


# In[ ]:





# In[4]:




#sort_distance_threshold=0.5


#
#output_dir = input_pdb_file[:-4]
#os.system('mkdir {}'.format(output_dir))
#print('mkdir {}'.format(output_dir))
#parser = PDBParser(PERMISSIVE = True, QUIET = True)
  
#io = PDBIO()

#connecting_atoms =[input_v_1[1], input_v_2[1]]

#input_structure = parser.get_structure('input',input_pdb_file)
#input_structure_atoms=[]
#for model in input_structure.get_models():
#    for chain in model.get_chains():
#      for residue in chain.get_residues():
#        for atom in residue.get_atoms():
#            distance = min([np.linalg.norm(atom.get_coord() - xyz) for xyz in connecting_atoms ])
#            if(distance>0.5): input_structure_atoms.append(atom)
#print(len(input_structure_atoms))                
            
#search(input_v_1, input_v_2)

def parse_input(input_csv):
   #A1.x,A1.y,A1.z,A2.x,A2.y,A2.z,B1.x,B1.y,B1.z,B2.x,B2.y,B2.z
   df_input=pd.read_csv(input_csv).iloc[0].to_dict()
   input_v_1 = [np.array((df_input['A1.x'],df_input['A1.y'],df_input['A1.z'])),
                np.array((df_input['A2.x'],df_input['A2.y'],df_input['A2.z']))]
   input_v_2 = [np.array((df_input['B1.x'],df_input['B1.y'],df_input['B1.z'])),
                np.array((df_input['B2.x'],df_input['B2.y'],df_input['B2.z']))]
   input_pdb_file =df_input['input_pdb']
   is_test = bool(df_input['is_test'])
   return is_test,input_pdb_file,input_v_1,input_v_2



if __name__ == "__main__":
  
  input_csv= sys.argv[1]
  print(sys.argv[1]) 
  is_test,input_pdb_file,input_v_1,input_v_2 = parse_input(input_csv)
  #input_v_1 = [np.array((129.466, 118.451, 136.12 )),np.array(( 129.177, 117.901, 137.010 ))]
  #input_v_2 = [np.array(( 127.943, 114.228, 132.256 ) ),np.array(( 127.083, 114.115, 132.916))]
  #input_pdb_file = 'KIF18A_macro.pdb'   
  print(is_test,input_pdb_file,input_v_1,input_v_2 )
  #is_test = False

  ligand_cycle_list = prepare_ligand_cycle_list()

  print(len(ligand_cycle_list))


  sort_distance_threshold=0.5


#
  output_dir = input_pdb_file[:-4]
  os.system('mkdir {}'.format(output_dir))
  print('mkdir {}'.format(output_dir))
  parser = PDBParser(PERMISSIVE = True, QUIET = True)

  io = PDBIO()

  connecting_atoms =[input_v_1[1], input_v_2[1]]

  input_structure = parser.get_structure('input',input_pdb_file)
  input_structure_atoms=[]
  for model in input_structure.get_models():
    for chain in model.get_chains():
      for residue in chain.get_residues():
        for atom in residue.get_atoms():
            distance = min([np.linalg.norm(atom.get_coord() - xyz) for xyz in connecting_atoms ])
            if(distance>0.5): input_structure_atoms.append(atom)
  print(len(input_structure_atoms))

  search(input_v_1, input_v_2)


#  

# In[ ]:




